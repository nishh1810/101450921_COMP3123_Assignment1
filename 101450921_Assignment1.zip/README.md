# 3123- Assignment 1
# Nishita Sachdev 
# 101450921
# All API working with database connection working 
# Postman and MongoDBCompass connection screenshots provided 
# All Requirements done
# Hosted at https://one01450921-comp3123-assignment1.onrender.com/api/v1/emp/employees/
